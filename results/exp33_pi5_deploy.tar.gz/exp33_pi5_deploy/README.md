# LeNet-300-100 MNIST — Exp 33 Pi5 Deploy Package

## Architecture
Input 784 → FC(80) → FC(30) → Output 10

Derived from two-phase neuron+weight Glauber pruning (Mozeika & Pizzoferrato 2026):
- Phase 1: neuron Glauber — 60.7% neuron sparsity removed, acc improved 97.22%→98.21%
- Phase 2: OBD weight pruning — 97.6% weight sparsity, acc 97.50%
- Dead neuron removal: fc1 -42 neurons, fc2 -5 neurons
- Effective architecture: 784→80→30→10

## Files
- `truly_compact_int8.onnx`  — INT8 static quantized, 68.3 KB  ← primary deploy artifact
- `truly_compact_net.onnx`   — FP32 baseline, 1.8 KB
- `infer.py`                 — standalone inference + benchmark script

## Accuracy
| Model       | Accuracy |
|-------------|----------|
| FP32 dense  | 95.19%  |
| INT8 static | 95.06%  |
| Quant drop  | 0.130 pp |

## Install on Pi5
```bash
pip install onnxruntime numpy pillow
python3 infer.py --benchmark
```

## Single image inference
```bash
python3 infer.py digit.png
```
