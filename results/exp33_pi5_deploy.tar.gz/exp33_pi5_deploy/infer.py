#!/usr/bin/env python3
"""
LeNet-300-100 MNIST inference — Pi5 deploy (Exp 33)
Requires: onnxruntime, numpy, Pillow

Usage:
    python3 infer.py image.png
    python3 infer.py --benchmark   # 1000-sample throughput test (needs MNIST)
"""

import sys
import numpy as np
import onnxruntime as ort

LABELS = list(range(10))
MODEL  = "truly_compact_int8.onnx"   # or truly_compact_net.onnx for FP32


def preprocess(img_array: np.ndarray) -> np.ndarray:
    """img_array: (28, 28) uint8 or float, 0-255"""
    x = img_array.astype(np.float32) / 255.0
    x = (x - 0.1307) / 0.3081
    return x.reshape(1, 1, 28, 28)  # (batch=1, C=1, H=28, W=28)


def load_image(path: str) -> np.ndarray:
    from PIL import Image
    img = Image.open(path).convert("L").resize((28, 28))
    return np.array(img)


def run_inference(img_path: str):
    sess  = ort.InferenceSession(MODEL, providers=["CPUExecutionProvider"])
    name  = sess.get_inputs()[0].name
    arr   = preprocess(load_image(img_path))
    out   = sess.run(None, {name: arr})[0]
    probs = np.exp(out[0]) / np.exp(out[0]).sum()
    pred  = int(probs.argmax())
    print(f"Prediction: {pred}  (confidence: {probs[pred]*100:.1f}%)")
    for i, p in enumerate(probs):
        bar = "#" * int(p * 40)
        print(f"  {i}: {bar:<40} {p*100:5.1f}%")


def benchmark():
    import time
    import torchvision.datasets as dsets
    import torchvision.transforms as T

    ds  = dsets.MNIST("/tmp/mnist_data", train=False, download=True,
                      transform=T.Compose([T.ToTensor(),
                                           T.Normalize((0.1307,), (0.3081,))]))
    ldr = __import__("torch").utils.data.DataLoader(ds, batch_size=1000)
    sess = ort.InferenceSession(MODEL, providers=["CPUExecutionProvider"])
    name = sess.get_inputs()[0].name

    correct = total = 0
    t0 = time.perf_counter()
    for x, y in ldr:
        x_np = x.numpy().astype(np.float32)  # keep (batch, 1, 28, 28)
        preds = sess.run(None, {name: x_np})[0].argmax(axis=1)
        correct += (preds == y.numpy()).sum()
        total   += y.shape[0]
    elapsed = time.perf_counter() - t0

    print(f"Accuracy:   {correct/total*100:.2f}%")
    print(f"Throughput: {total/elapsed:.0f} samples/sec")
    print(f"Latency:    {elapsed/total*1000:.3f} ms/sample")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    if sys.argv[1] == "--benchmark":
        benchmark()
    else:
        run_inference(sys.argv[1])
